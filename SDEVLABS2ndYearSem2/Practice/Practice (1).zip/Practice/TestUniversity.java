package Practice;

import java.sql.ResultSet;
import java.util.ArrayList;





class TestUniversity
{
	public static void main(String[] args){
        CreateUniTable c = new CreateUniTable();
        c.openDB();
        c.dropTables();
        c.CreateTables();
        ResultSet r = c.query1DB1();
        int [] id;
        String [] name;
        while(r.next())
        {
            id = {r.getInt(1)};
            name = r.getString(2);
        }

		University u1 = new University("TCD","Mr Bloggs","Dublin", id, name);
		


		University u2 =new University("UCD","Mr Baker","Dublin", udepids, udepnames);
		
		ArrayList<University> ulist = new ArrayList<University>();
		ulist.add(u1);
		ulist.add(u2);

       UniGUI u = new UniGUI(ulist);
		
	}
}
