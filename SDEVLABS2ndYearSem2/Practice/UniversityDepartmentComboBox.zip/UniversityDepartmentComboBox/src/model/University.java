package UniversityDepartmentComboBox.src.model;



import Lab5Skeleton.src.model.Contact;
import UniversityDepartmentComboBox.src.samplepgmSeqPKFK.src.database.CreateUniTable;

import java.sql.ResultSet;
import java.util.ArrayList;

public class University {
	private String uName;
	private String president;
	private String location;
	private ArrayList<Department> deptlist = new ArrayList<Department>();
    private ResultSet rset;
    private CreateUniTable cr;


	public University(CreateUniTable c) {
        cr = c;
	}

    public void refreshList( int count) {

        rset = cr.getDepartment(count);


        if (deptlist.size() > 0) {

            for (int i = deptlist.size()-1; i >=0; i--) {
                deptlist.remove(i);
            }
        }
        try {
            while (rset.next()) {
                Department c = new Department(rset.getInt(1), rset.getString(2));
                deptlist.add(c);
            }

        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public void refreshListUniversity(int count) {
        rset = cr.getUniversity(count);

        try {
            if (rset.next()) {
                uName = rset.getString(1);
                president = rset.getString(3);
                location = rset.getString(2);
            }

        } catch (Exception e) {
            System.out.println(e);
        }

    }

	public String getuName() {
		return uName;
	}

	public String getPresident() {
		return president;
	}

	public String getLocation() {
		return location;
	}

	public Department getDept(int i) {
		return deptlist.get(i);
	}

	public int getNumDept() {
		return deptlist.size();
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public void addDep(Department d) {
		deptlist.add(d);
	}
	public void changedeptname(String old, String newname) {
		for (int i = 0; i < deptlist.size(); i++) {
			if (deptlist.get(i).getDeptName().equals(old))
				deptlist.get(i).setDeptName(newname);
		}
	}
	public int findDep(String n) {
		int returnValue = -1; // -1 if there is no match
		for (int i = 0; i < deptlist.size(); i++) {
			if (n.equals(deptlist.get(i).getDeptName()))
				returnValue = i;
		}
		return returnValue;
	}
	public int removeDep(String name)
	{
		int num = 0;
		for (int i=0;i<deptlist.size();i++)
		{
			if((name.equals(deptlist.get(i).getDeptName())))
			{
				deptlist.remove(i);
				num++;
			}
		}
		return num;
	}
}
