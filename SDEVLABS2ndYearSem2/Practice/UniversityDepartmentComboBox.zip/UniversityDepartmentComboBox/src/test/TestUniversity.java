

import UniversityDepartmentComboBox.src.gui.UniGUI;
import UniversityDepartmentComboBox.src.model.University;
import UniversityDepartmentComboBox.src.samplepgmSeqPKFK.src.database.CreateUniTable;

import java.util.ArrayList;



class TestUniversity
{
	public static void main(String[] args){


        CreateUniTable c = new CreateUniTable();
        c.openDB();
        c.dropTables();
        c.CreateTables();

		University u1 = new University(c);
        u1.refreshList(1);
        u1.refreshListUniversity(1);
		University u2 = new University(c);
        u2.refreshList(2);
        u2.refreshListUniversity(2);
		ArrayList<University> ulist = new ArrayList<University>();
		ulist.add(u1);
		ulist.add(u2);

        UniGUI u = new UniGUI(ulist,c);
		
	}
}
